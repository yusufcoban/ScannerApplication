﻿using Backend.Models;

using schnittstelle_erp_backend.Handler;

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Backend.Basis
{
    public class ItemNoValidation : ValidationAttribute
    {
        public relACHandler relAcHandler = new relACHandler();
        public override bool IsValid(object value)
        {
            relAc item = relAcHandler.GetByMNr(value.ToString());
            if (item != null)
            {
                return true;
            }
            return false;
        }
    }
}
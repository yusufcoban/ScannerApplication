﻿using Backend.Models;

using Dapper;

using ERP_Api.SQL;

using System.Collections.Generic;
using System.Data;

namespace schnittstelle_erp_backend.Handler
{

    public class relISSPurchUserHandler
    {
        
        public IEnumerable<relISSPurchUser> Get()
        {
            using (IDbConnection connection = MSSQLconn.GetConnection())
            {
                IEnumerable<relISSPurchUser> sampleNumbers;
                string sqlQuery;
                if (connection.TryGenerateSelectForProperties<relISSPurchUser>(out sqlQuery))
                {
                    sampleNumbers = connection.Query<relISSPurchUser>(sqlQuery);
                }
                else
                {
                    sampleNumbers = new List<relISSPurchUser>();
                }

                return sampleNumbers;
            }
        }
    }
}
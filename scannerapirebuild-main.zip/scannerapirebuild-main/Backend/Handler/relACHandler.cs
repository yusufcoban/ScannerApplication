﻿using Backend.Basis;
using Backend.Models;

using Dapper;

using ERP_Api.SQL;

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;

namespace schnittstelle_erp_backend.Handler
{
    public class relACHandler
    {

        public IEnumerable<relAc> Get()
        {
            using (IDbConnection connection = MSSQLconn.GetConnection())
            {
                IEnumerable<relAc> sampleNumbers;
                string sqlQuery;
                if (connection.TryGenerateSelectForProperties<relAc>(out sqlQuery))
                {
                    sampleNumbers = connection.Query<relAc>(sqlQuery);
                }
                else
                {
                    sampleNumbers = new List<relAc>();
                }

                return sampleNumbers;
            }
        }


        /// <summary>
        /// Gets the part number with the given id from the database
        /// </summary>
        /// <param name="id">The <see cref="PartNumbers.ID"/></param>
        /// <returns>The part number</returns>
        public relAc GetTest(string id)
        {
            using (IDbConnection connection = MSSQLconn.GetConnection())
            {
                relAc partNumber = null;
                string sqlQuery;
                if (connection.TryGenerateSelectForProperties<relAc>(out sqlQuery, null, false))
                {
                    string propertyName = string.Empty;
                    IEnumerable<PropertyInfo> infos = typeof(relAc).GetProperties();
                    IEnumerable<PropertyInfo> filterStep1 = infos?.Where(x => x.CustomAttributes.Any());
                    string propertyNameOfObject = String.Empty;
                    bool isStringField = false;
                    foreach (PropertyInfo propertyInfoLoop in filterStep1)
                    {
                        string x = propertyInfoLoop.PropertyType.FullName;
                        foreach (Attribute item in propertyInfoLoop.GetCustomAttributes())
                        {
                            if (item.GetTableName().Equals("IdentifierSingle"))
                            {
                                propertyNameOfObject = propertyInfoLoop.Name;
                                if (propertyInfoLoop.PropertyType.Name.Equals("String"))
                                {
                                    isStringField = true;
                                }
                            }
                        }
                    }

                    sqlQuery += " WHERE ";
                    if (!string.IsNullOrEmpty(propertyNameOfObject))
                    {

                        sqlQuery += "[" + propertyNameOfObject + "] ";
                        if (isStringField)
                        {
                            sqlQuery += " LIKE @Id";
                        }
                        else
                        {
                            sqlQuery += " = @Id";
                        }
                    }
                    else
                    {
                        sqlQuery += " [IK] = @Id";
                    }

                    partNumber = connection.QueryFirstOrDefault<relAc>(sqlQuery, new { Id = id });
                }

                return partNumber;
            }
        }
        public relAc GetByMNr(string id)
        {
            using (IDbConnection connection = MSSQLconn.GetConnection())
            {
                relAc partNumber = null;
                string sqlQuery;
                if (connection.TryGenerateSelectForProperties<relAc>(out sqlQuery, null, false))
                {
                    sqlQuery += " WHERE MNR = @ID";
                    partNumber = connection.QueryFirstOrDefault<relAc>(sqlQuery, new { Id = id });
                }

                return partNumber;
            }
        }

    }
}
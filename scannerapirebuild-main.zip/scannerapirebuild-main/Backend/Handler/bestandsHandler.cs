﻿using Backend.Basis;
using Backend.Models;

using Dapper;

using ERP_Api.SQL;

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;

namespace schnittstelle_erp_backend.Handler
{
    public class bestandsHandler
    {
        private string query = @" SELECT *
                                  FROM relISSStock StockPart 
                                  INNER JOIN relISSStockPath PathPart ON StockPart.PathNo = PathPart.PathNo 
                                  WHERE  StockPart.ItemNo = @Mnr ";

        private string queryLager = @" SELECT *
                                  FROM relISSStock StockPart 
                                  INNER JOIN relISSStockPath PathPart ON StockPart.PathNo = PathPart.PathNo 
                                  WHERE StockArea = @StockArea ";

        public IEnumerable<dynamic> Get(string Mnr)
        {
            using (IDbConnection connection = MSSQLconn.GetConnection())
            {
                return connection.Query<dynamic>(query, new { Mnr = Mnr });
            }
        }

        public IEnumerable<dynamic> GetByLager(string stockArea)
        {
            using (IDbConnection connection = MSSQLconn.GetConnection())
            {
                if (stockArea.Contains('.'))
                {
                    // Could be like 51.2.3.23.
                    string[] stringBuffer = stockArea.Split(new[] { '.' }, 2);
                    queryLager += "And PathName = @PathName";
                    return connection.Query<dynamic>(queryLager, new { StockArea = stringBuffer[0], PathName = stringBuffer[1] });
                }
                else
                {
                    // StockArea only 
                    return connection.Query<dynamic>(queryLager, new { StockArea = stockArea });
                }
            }

        }
    }
}
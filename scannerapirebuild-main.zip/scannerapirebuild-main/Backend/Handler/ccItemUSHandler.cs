﻿using System.Collections.Generic;
using System.Data;

using Backend.Models;

using Dapper;

using ERP_Api.SQL;

namespace schnittstelle_erp_backend.Handler
{

    public class ccItemUSHandler
    {

        public IEnumerable<ccItemUS> Get()
        {
            using (IDbConnection connection = MSSQLconn.GetConnection())
            {
                IEnumerable<ccItemUS> ccItemUsCollection;
                string sqlQuery;
                if (connection.TryGenerateSelectForProperties<ccItemUS>(out sqlQuery))
                {
                    ccItemUsCollection = connection.Query<ccItemUS>(sqlQuery);
                }
                else
                {
                    ccItemUsCollection = new List<ccItemUS>();
                }

                return ccItemUsCollection;
            }
        }

        /// <summary>
        /// Gets the part number with the given id from the database
        /// </summary>
        /// <param name="id">The <see cref="PartNumbers.ID"/></param>
        /// <returns>The part number</returns>
        public ccItemUS Get(int id)
        {
            using (IDbConnection connection = MSSQLconn.GetConnection())
            {
                ccItemUS partNumber = null;
                string sqlQuery;
                if (connection.TryGenerateSelectForProperties<ccItemUS>(out sqlQuery, null, false))
                {
                    sqlQuery += " WHERE [IK] = @Id";
                    partNumber = connection.QueryFirstOrDefault<ccItemUS>(sqlQuery, new { Id = id });
                }

                return partNumber;
            }
        }

    }
}
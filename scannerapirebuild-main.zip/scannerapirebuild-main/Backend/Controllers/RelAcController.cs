﻿using Backend.Models;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using schnittstelle_erp_backend.Handler;

using System.Collections.Generic;
using System.Web.Http;

using HttpGetAttribute = Microsoft.AspNetCore.Mvc.HttpGetAttribute;

namespace Backend.Controllers
{
    [ApiController]
   // [Route("[RelAcController]")]
    public class RelAcController : ApiController
    {
        private relACHandler relachandler = new relACHandler();

        private readonly ILogger<RelAcController> _logger;

        public RelAcController(ILogger<RelAcController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IEnumerable<relAc> Get()
        {
            return relachandler.Get();
        }


        [HttpGet]
        public relAc GetById(string id)
        {
            return relachandler.GetByMNr(id);
        }

        public RelAcController()
        {

        }
    }
}

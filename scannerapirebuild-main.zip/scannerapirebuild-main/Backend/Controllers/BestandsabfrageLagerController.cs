﻿using Backend.InputModels;

using Microsoft.AspNetCore.Mvc;

using schnittstelle_erp_backend.Handler;

using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

using HttpPostAttribute = System.Web.Http.HttpPostAttribute;

namespace Backend.Controllers
{
    [ApiController]
    public class BestandsabfrageLagerController : ApiController
    {
        public bestandsHandler bestandsHandlerObject = new bestandsHandler();

        [HttpPost]
        [ResponseType(typeof(IEnumerable<dynamic>))]
        public IHttpActionResult GetByLager(InputBestandsabfrageLager inputBestandsabfrageLager)
        {
            if (ModelState.IsValid)
            {
                IEnumerable<dynamic> lagerbestaende = bestandsHandlerObject.GetByLager(inputBestandsabfrageLager.Lagerbezeichnung);
                if (lagerbestaende.Any())
                {
                    return Ok(lagerbestaende);
                }
                else
                {
                    return NotFound();
                }
            }
            return BadRequest(ModelState);
        }
    }
}

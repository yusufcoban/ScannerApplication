﻿using Backend.InputModels;

using Microsoft.AspNetCore.Mvc;

using schnittstelle_erp_backend.Handler;

using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Description;

using HttpPostAttribute = System.Web.Http.HttpPostAttribute;

namespace Backend.Controllers
{
    [ApiController]
    public class BestandsabfrageController : ApiController
    {
        public bestandsHandler bestandsHandlerObject = new bestandsHandler();

        [HttpPost]
        [ResponseType(typeof(IEnumerable<dynamic>))]
        public IHttpActionResult Get(InputBestandsabfrage inputBestandsabfrage)
        {
            if (ModelState.IsValid)
            {
                IEnumerable<dynamic> lagerbestaende = bestandsHandlerObject.Get(inputBestandsabfrage.ItemNo);
                if (lagerbestaende.Any())
                {
                    return Ok(lagerbestaende);
                }
                else
                {
                    return NotFound();
                }
            }
            return BadRequest(ModelState);
        }
    }
}

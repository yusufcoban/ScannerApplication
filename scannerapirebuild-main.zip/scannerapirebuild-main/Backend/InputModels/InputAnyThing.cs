﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Backend.InputModels
{
    public class InputAnyThing
    {
        public string barcodeItem { get; set; }
        public string barcodeReference { get; set; }

    }

}
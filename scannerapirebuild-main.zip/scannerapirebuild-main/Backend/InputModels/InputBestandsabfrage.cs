﻿using Backend.Basis;

using System.ComponentModel.DataAnnotations;

namespace Backend.InputModels
{
    public class InputBestandsabfrage
    {
        [Required]
        [ItemNoValidation]
        public string ItemNo { get; set; }
    }

    public class InputBestandsabfrageLager
    {
        [Required]
        public string Lagerbezeichnung { get; set; }
    }
}